//
//  SettingVC.swift
//  TodoList
//
//  Created by MacBook on 22/05/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit

class SettingVC: UIViewController,SWRevealViewControllerDelegate {
    @IBOutlet weak var sideMenuButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        if revealViewController() != nil {
            revealViewController().delegate = self
            sideMenuButton.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
}
