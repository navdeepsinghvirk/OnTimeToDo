//
//  AddNewTaskInGroupCell.swift
//  TodoList
//
//  Created by MacBook on 09/07/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit

class AddNewTaskInGroupCell: UITableViewCell {

    @IBOutlet weak var btn_delete: UIButton!
    @IBOutlet weak var lbl_taskTitle: UILabel!
    @IBOutlet weak var btn_edit: UIButton!
    @IBOutlet weak var lbl_deadline: UILabel!
    @IBOutlet var lbl_todoTitle: UILabel!
    @IBOutlet weak var img_delete: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
}
