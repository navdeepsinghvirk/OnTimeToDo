//
//  HomeVC.swift
//  TodoList
//
//  Created by MacBook on 22/05/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import  CoreData

class HomeVC: UIViewController,SWRevealViewControllerDelegate {
    
    @IBOutlet weak var popUpMessage: UILabel!
    @IBOutlet weak var sideMenuButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    let userDefault = UserDefaults.standard
    var myArray = [NSManagedObject]()

    override func viewDidLoad() {
        super.viewDidLoad()
        if revealViewController() != nil {
            revealViewController().delegate = self
            sideMenuButton.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        
        setUpTableView()
        let defaultEmail = userDefault.string(forKey: "email") ?? ""
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest <NSFetchRequestResult> (entityName: "Group")
        request.predicate = NSPredicate(format: "email == %@", defaultEmail)
        request.returnsObjectsAsFaults = false
        do {
            let results = try context.fetch(request)
            // check data existance
            if results.count>0 {
                self.popUpMessage.isHidden = true
                print(results.count)
                
                for resultGot in results as! [NSManagedObject]{
                    myArray.append(resultGot)
                    print("my array is : \(myArray )")
                }
            }
        }catch{
            print("No Data to load")
        }
    }
    
    func setUpTableView() {
        tableView.register(UINib(nibName: "HomePageCell", bundle: nil), forCellReuseIdentifier: "HomePageCell")
    }
}

extension HomeVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "HomePageCell", for: indexPath) as! HomePageCell
        let dict:NSManagedObject = myArray[indexPath.row]
        
        cell.lbl_todoTitle.text = dict.value(forKey: "groupType") as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80.0
    }
}
