//
//  AddTaskGroupVC.swift
//  TodoList
//
//  Created by MacBook on 22/05/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import CoreData


class AddTaskGroupVC: UIViewController,SWRevealViewControllerDelegate {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var sideMenuButton: UIButton!
    @IBOutlet weak var popUpMessage: UILabel!

    var todoTitleTextField = UITextField()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var todoList: [[String:String]] = []
    let userDefault = UserDefaults.standard
    var defaultEmail = String()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if revealViewController() != nil {
            revealViewController().delegate = self
            sideMenuButton.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.todoList.removeAll()
        self.tableView.reloadData()
        defaultEmail = userDefault.string(forKey: "email") ?? ""
        setUpTableView()
        getAllGroups()
    }
    
    func setUpTableView() {
        tableView.register(UINib(nibName: "TodoCell", bundle: nil), forCellReuseIdentifier: "TodoCell")
    }
    
    func getAllGroups(){
        let request = NSFetchRequest <NSFetchRequestResult> (entityName: "Group")
        request.predicate = NSPredicate(format: "email == %@", defaultEmail)
        request.returnsObjectsAsFaults = false
        do {
            let context = appDelegate.persistentContainer.viewContext
            let results = try context.fetch(request)
            // check data existance
            if results.count>0 {
                print(results.count)
                self.popUpMessage.isHidden = true

                for dict in results as! [NSManagedObject]{
                        if let groupType = dict.value(forKey: "groupType") as? String{
                            let email = (dict.value(forKey: "email") as? String)!
                            
                            let dict: [String:String] = ["email":email,"groupType":groupType]
                            self.todoList.append(dict)
                    }
                }
                self.tableView.reloadData()
            }
        }catch{
            print("No Data to load")
        }
    }
    
    @IBAction func actionOnAddButn(_ sender: UIButton) {
        let alert = UIAlertController(title: "Add Group", message: "", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let action = UIAlertAction(title: "Add", style: .default) { (action) in
            let context = self.appDelegate.persistentContainer.viewContext
            
            // Context can't be nil & also Make todoTaskTextField mandatory
            if self.todoTitleTextField.text != ""{
                let newUser = NSEntityDescription.insertNewObject(forEntityName: "Group", into: context)
                newUser.setValue(self.todoTitleTextField.text, forKey: "groupType")
                newUser.setValue(self.defaultEmail, forKey: "email")
                
                let dict: [String:String] = ["email":self.defaultEmail,"groupType":self.todoTitleTextField.text!]
                self.todoList.append(dict)
                do{
                    try context.save()
                    self.popUpMessage.isHidden = true
                    self.tableView.reloadData()
                }catch{
                    fatalError("Error storing data")
                }
            }else{
                SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.taskAlertMessages.enterToDoTask, viewController: self)
                return
            }
        }
        
        alert.addTextField { (textField) in
            textField.placeholder = "Add Group"
            self.todoTitleTextField = textField
        }
        
        alert.addAction(action)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
    }
}

// MARK: - Extension for tableview methods
extension AddTaskGroupVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TodoCell", for: indexPath) as! TodoCell
        let dict = todoList[indexPath.row]
        cell.lbl_todoTitle.text = dict["groupType"] ?? ""
        cell.btn_edit.tag = indexPath.row
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dict = todoList[indexPath.row]
       let str_groupType = dict["groupType"] ?? ""
        
        let addNewTaskListingVar = self.storyboard?.instantiateViewController(withIdentifier: "AddNewTaskListingVC") as! AddNewTaskListingVC
        addNewTaskListingVar.groupType = str_groupType
        self.navigationController?.pushViewController(addNewTaskListingVar, animated: true)
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60.0
    }
}
