//
//  SignUpVC.swift
//  TodoList
//
//  Created by MacBook on 22/05/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import CoreData

class SignUpVC: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    @IBOutlet weak var tf_name: UITextField!
    @IBOutlet weak var tf_email: UITextField!
    @IBOutlet weak var tf_password: UITextField!
    @IBOutlet weak var tf_phone: UITextField!
    @IBOutlet weak var profileImage: UIImageView!
    var imagePicker = UIImagePickerController()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate

    let userDefault = UserDefaults.standard
    var newUser = NSManagedObject()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        // ********4 things********
        // 1: refer to persistent container :already in app delegate
        // 2: create context
        // 3: create entity and 4:new user record
    }
    
    func setUp(){
        tf_email.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.emailText, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        tf_password.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.passwordText, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        tf_name.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.name, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        tf_phone.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.phoneNumber, attributes:[NSAttributedStringKey.foregroundColor: UIColor.white])
    }
    
    func valid() -> Bool{
        var isValid: Bool = true
        if (tf_email.text?.count == 0){
            isValid = false
            SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.alertMessages.emailFields, viewController: self, okAction: { () -> () in
            })
        } else if(tf_password.text?.count == 0){
            isValid = false
            SwiftAlert().show(title: GlobalConstants.appDetails.appName, message:GlobalConstants.alertMessages.passwordFields, viewController: self, okAction: { () -> () in
            })
        }
        else if(tf_name.text?.count == 0){
            isValid = false
            SwiftAlert().show(title: GlobalConstants.appDetails.appName, message:GlobalConstants.alertMessages.nameFields, viewController: self, okAction: { () -> () in
            })
        }
        else if(tf_phone.text?.count == 0){
            isValid = false
            SwiftAlert().show(title: GlobalConstants.appDetails.appName, message:GlobalConstants.alertMessages.phoneNumberFields, viewController: self, okAction: { () -> () in
            })
        }
        return isValid
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            profileImage.image = pickedImage
        }
    }
    
    @IBAction func actionOnPickProfileImage(_ sender: UIButton) {
        
        let alert = UIAlertController(title:GlobalConstants.appDetails.appName, message: "Choose Any Picture", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title:"Camera", style: .default) { (action) in
            // self.imagePicker.sourceType = .camera
           // self.present(self.imagePicker, animated: true, completion: nil)
        }
        let galleryAction = UIAlertAction(title:"Gallery", style: .default) { (action) in
            self.imagePicker.sourceType = .photoLibrary
            self.present(self.imagePicker, animated: true, completion: nil)
        }
        let cancelAction = UIAlertAction(title:"Cancel", style: .cancel) { (action) in
        }
        
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)

    }
    @IBAction func actionOnSaveBtn(_ sender: UIButton) {
        if valid(){
            //5: add data to our newly created record:---
            let newUser = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context)
            newUser.setValue(tf_name.text, forKey: "name")
            newUser.setValue(tf_password.text, forKey: "password")
            newUser.setValue(tf_email.text, forKey: "email")
            newUser.setValue(tf_phone.text, forKey: "phoneNumber")
            
            var imageData:Data = Data()
            if let data = UIImageJPEGRepresentation(profileImage.image ?? UIImage(), 0.5) {
                imageData = data
            }
            newUser.setValue(imageData, forKey: "img")

            do{
                try context.save()
                SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.successMessages.registeredSuccessfully, viewController: self) {
                    let signInVar = self.storyboard?.instantiateViewController(withIdentifier: "SignInVC") as! SignInVC
                    self.navigationController?.pushViewController(signInVar, animated: true)
                }
            }catch{
                print("failure")
            }
        }
    }
      
    @IBAction func actionOnBackButn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension SignUpVC : UITextFieldDelegate{
    internal func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case tf_name:
            tf_email.becomeFirstResponder()
        case tf_email:
            tf_password.becomeFirstResponder()
        case tf_password:
            tf_phone.becomeFirstResponder()
        case tf_phone:
            tf_phone.resignFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return true
    }
}
