//
//  AddNewTaskListingVC.swift
//  TodoList
//
//  Created by MacBook on 29/06/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import CoreData

enum ToDoStatus:String{
    case Done = "Done"
    case WorkInProgress = "Work in progress"
    case Pending = "Pending"
}

class AddNewTaskListingVC: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var popUpMessage: UILabel!
    @IBOutlet weak var lbl_title: UILabel!
    
    var taskTitleTextField = UITextField()
    var todoTitleTextField = UITextField()
    var todoDeadlineTextField = UITextField()
    var todoStatusTextField = UITextField()
    
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    var groupType = String()
    var todoList: [[String:String]] = []
    
    let userDefault = UserDefaults.standard
    var defaultEmail = String()
    var arr_status: [String] = []
    var str_selectedStatus = String()
    
    let datePicker = UIDatePicker()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arr_status = ["Pending","Work in progress","Done"]
        print("taskkkkkk",self.groupType)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.todoList.removeAll()
        self.tableView.reloadData()
        self.lbl_title.text = self.groupType
        defaultEmail = userDefault.string(forKey: "email") ?? ""
        getTaskListing()
        setUpTableView()
    }
    
    func getTaskListing(){
        let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: "Tasks")
        fetchRequest.predicate = NSPredicate(format: "email == %@", defaultEmail)
        fetchRequest.returnsObjectsAsFaults = true
        
        do {
            let context = appDelegate.persistentContainer.viewContext
            let results = try context.fetch(fetchRequest)
            
            // check data existance
            if results.count>0 {
                for dict in results as! [NSManagedObject]{
                    let str_groupType = dict.value(forKey: "groupType") as? String
                    print("groupType********during get****",groupType)
                    if str_groupType == self.groupType{
                        self.popUpMessage.isHidden = true
                        if let groupName = dict.value(forKey: "groupType") as? String{
                            let email = (dict.value(forKey: "email") as? String)!
                            let taskName = (dict.value(forKey: "taskName") as? String) ?? ""
                            let taskDeadline = (dict.value(forKey: "taskDeadline") as? String) ?? ""
                            let taskStatus = (dict.value(forKey: "status") as? String) ?? ""
                            let taskTitle = (dict.value(forKey: "title") as? String) ?? ""
                            
                            let dict: [String:String] = ["email":email,"groupType":groupName,"taskName":taskName,"taskDeadline":taskDeadline,"status":taskStatus,"title":taskTitle]
                            self.todoList.append(dict)
                            self.tableView.reloadData()
                        }
                    }
                }
            }
        }catch{
            print("error")
        }
    }
    
    func setUpTableView() {
        tableView.register(UINib(nibName: "AddNewTaskInGroupCell", bundle: nil), forCellReuseIdentifier: "AddNewTaskInGroupCell")
    }
    
    func addPicker(to textField: UITextField) {
        let PickerView:UIPickerView = UIPickerView()
        PickerView.delegate = self
        PickerView.dataSource = self
        textField.inputView = PickerView
    }
    
    func addDatePicker(to textField: UITextField) {
        self.datePicker.datePickerMode = .date
        if let dateText = textField.text, dateText != "" {
            datePicker.date = dateText.toDate(withFormattar: "yyyy-MM-dd") ?? Date()
        }
        datePicker.addTarget(self, action: #selector(AddNewTaskListingVC.datePickerDateDidChange(sender:)), for: UIControlEvents.valueChanged)
        textField.inputView = datePicker
        textField.text = formatDate(datePicker.date)
    }
    
    @objc func datePickerDateDidChange(sender: UIDatePicker) {
        self.todoDeadlineTextField.text = formatDate(datePicker.date)
    }
    
    func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
    
    @IBAction func addTodoPressed(_ sender: Any){
        let alert = UIAlertController(title: "Add Group Task", message: "", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let action = UIAlertAction(title: "Add Task", style: .default) { (action) in
            let context = self.appDelegate.persistentContainer.viewContext
            
            // Context can't be nil & also Make todoTaskTextField mandatory
            if self.todoTitleTextField.text != ""{
                let newUser = NSEntityDescription.insertNewObject(forEntityName: "Tasks", into: context)
                newUser.setValue(self.todoTitleTextField.text, forKey: "taskName")
                newUser.setValue(self.groupType, forKey: "groupType")
                newUser.setValue(self.defaultEmail, forKey: "email")
                newUser.setValue(self.todoDeadlineTextField.text, forKey: "taskDeadline")
                newUser.setValue(self.todoStatusTextField.text, forKey: "status")
                newUser.setValue(self.taskTitleTextField.text, forKey: "title")
                
                let dict: [String:String] = ["email":self.defaultEmail,"taskName":self.todoTitleTextField.text!,"groupType":self.groupType,"taskDeadline": self.todoDeadlineTextField.text!,"status":self.todoStatusTextField.text!,"title":self.taskTitleTextField.text!]
                
                self.todoList.append(dict)
                do{
                    try context.save()
                    self.popUpMessage.isHidden = true
                    self.tableView.reloadData()
                }catch{
                    fatalError("Error storing data")
                }
            }else{
                SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.taskAlertMessages.enterToDoTask, viewController: self)
                return
            }
        }
        
        alert.addTextField { (textField) in
            textField.delegate = self
            textField.placeholder = "Task Title"
            self.taskTitleTextField = textField
        }
        
        alert.addTextField { (textField) in
            textField.delegate = self
            textField.placeholder = "Task Description"
            self.todoTitleTextField = textField
        }
        
        alert.addTextField { (textField) in
            self.addDatePicker(to: textField)
            textField.placeholder = "Task Deadline"
            self.todoDeadlineTextField = textField
        }
        
        alert.addTextField { (textField) in
            self.addPicker(to: textField)
            textField.placeholder = "Task Status"
            self.todoStatusTextField = textField
        }
        
        alert.addAction(action)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func actionOnBackButn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
}

// MARK: - Extension for tableview methods
extension AddNewTaskListingVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddNewTaskInGroupCell", for: indexPath) as! AddNewTaskInGroupCell
        let dict = todoList[indexPath.row]
        let str_status = dict["status"] ?? ""
        if str_status == ToDoStatus.Pending.rawValue{
            cell.backgroundColor = UIColor(red: 255/255.0, green: 59/255.0, blue: 16/255.0, alpha: 1)
        }else if str_status == ToDoStatus.Done.rawValue{
            cell.backgroundColor = UIColor(red: 58.0/255.0, green: 255/255.0, blue: 60/255.0, alpha: 1)
        }else if str_status == ToDoStatus.WorkInProgress.rawValue{
            cell.backgroundColor = UIColor(red: 255/255.0, green: 252/255.0, blue: 121/255.0, alpha: 1)
        }
        cell.lbl_todoTitle.text = dict["taskName"] ?? ""
        cell.lbl_deadline.text = dict["taskDeadline"] ?? ""
        cell.lbl_taskTitle.text = dict["title"] ?? ""
        cell.btn_edit.isHidden = true
        cell.img_delete.isHidden = true
        cell.btn_delete.isHidden = true
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let dict = todoList[indexPath.row]
        let descriptionScreen = self.storyboard?.instantiateViewController(withIdentifier: "ToDoDescriptionVC") as! ToDoDescriptionVC
        descriptionScreen.index = indexPath.row
        descriptionScreen.dict_todo = dict
        descriptionScreen.groupType = self.groupType
        self.navigationController?.pushViewController(descriptionScreen, animated: true)
    }
}

extension AddNewTaskListingVC:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return range.location < 50
    }
}

extension AddNewTaskListingVC: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arr_status.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.todoStatusTextField.text = arr_status[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        if row == 0{
            self.todoStatusTextField.text = arr_status[row]
        }
        return arr_status[row]
    }
}
