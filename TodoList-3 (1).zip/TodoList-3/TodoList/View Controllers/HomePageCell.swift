//
//  HomePageCell.swift
//  TodoList
//
//  Created by MacBook on 30/06/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit

class HomePageCell: UITableViewCell {

    @IBOutlet var lbl_todoTitle: UILabel!
    @IBOutlet var lbl_todoDescription: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
