//  ProfileVC.swift
//  TodoList
//
//  Created by MacBook on 30/05/19.
//  Copyright © 2019 MacBook. All rights reserved.

import UIKit
import CoreData


class ProfileVC: UIViewController,SWRevealViewControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate  {
    
    @IBOutlet weak var sideMenuButton: UIButton!
    @IBOutlet weak var bannerImage: UIImageView!
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var tf_name: UITextField!
    @IBOutlet weak var tf_email: UITextField!
    @IBOutlet weak var tf_phone: UITextField!
    
    let userDefault = UserDefaults.standard
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var userInformationArray = [NSManagedObject]()
    var defaultEmail = String()
    var imagePicker = UIImagePickerController()
    var imageViewButtonTag = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
        sideMenuSetUp()
        imagePicker.delegate = self
        imagePicker.allowsEditing = true
        
        //fetch record of registered user from database
        defaultEmail = userDefault.string(forKey: "email") ?? ""
        let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: "Users")
        fetchRequest.predicate = NSPredicate(format: "email == %@", defaultEmail)
        fetchRequest.returnsObjectsAsFaults = false
        let context = appDelegate.persistentContainer.viewContext
        
        do {
            let results = try context.fetch(fetchRequest)
            // check data existance
            if results.count>0 {
                var fetchedProfileImage = [UIImage]()
                var fetchedBannerImage = [UIImage]()
                for resultGot in results as! [NSManagedObject]{
                    userInformationArray.append(resultGot)
                    print("my array is : \(userInformationArray )")
                    for dict in userInformationArray{
                        tf_name.text = dict.value(forKey: "name") as? String
                        tf_email.text = dict.value(forKey: "email") as? String
                        tf_phone.text = dict.value(forKey: "phoneNumber") as? String
                        //added this is convert the image
                        let profileImageData = dict.value(forKey: "img") as? Data ?? Data()
                        fetchedProfileImage.append(UIImage(data: profileImageData)!)
                        let bannerImageData = dict.value(forKey: "bannerImg") as? Data ?? Data()
                        fetchedBannerImage.append(UIImage(data: bannerImageData) ?? UIImage(named: "banner")!)
                    }
                }
                self.profileImage.image = fetchedProfileImage.first
                self.bannerImage.image = fetchedBannerImage.first
            }
        }catch{
            print("No Data to load")
        }
    }
    
    func setUp(){
        tf_email.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.emailText, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        tf_name.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.name, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        tf_phone.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.phoneNumber, attributes:[NSAttributedStringKey.foregroundColor: UIColor.white])
    }
    
    func sideMenuSetUp(){
        if revealViewController() != nil {
            revealViewController().delegate = self
            sideMenuButton.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        imagePicker.dismiss(animated: true, completion: nil)
        
        if let pickedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            if self.imageViewButtonTag == 1{
            profileImage.image = pickedImage
            }else if self.imageViewButtonTag == 2{
            bannerImage.image = pickedImage
            }
        }
    }
    
    func chooseImagesForDisplay(){
        let alert = UIAlertController(title:GlobalConstants.appDetails.appName, message: "Choose Any Picture", preferredStyle: .actionSheet)
        let cameraAction = UIAlertAction(title:"Camera", style: .default) { (action) in
             // Note1:- If you want to pick image from Camera
            //  self.imagePicker.sourceType = .camera
            // Note2:- If you want to pick image from gallary not from camera for now then uncomment this below line
            //self.present(self.imagePicker, animated: true, completion: nil)
        }
        let galleryAction = UIAlertAction(title:"Gallery", style: .default) { (action) in
            self.imagePicker.sourceType = .photoLibrary
            self.present(self.imagePicker, animated: true, completion: nil)
        }
        let cancelAction = UIAlertAction(title:"Cancel", style: .cancel) { (action) in
        }
        
        alert.addAction(cameraAction)
        alert.addAction(galleryAction)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func actionOnPickProfileImage(_ sender: UIButton) {
      self.imageViewButtonTag = 1
      chooseImagesForDisplay()
    }
    
    @IBAction func actionOnPickBannerImg(_ sender: UIButton) {
        self.imageViewButtonTag = 2
        chooseImagesForDisplay()
    }
    
    @IBAction func actionOnSaveButn(_ sender: UIButton) {
        let managedContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: managedContext)
        let request = NSFetchRequest<NSFetchRequestResult>()
        request.entity = entity
        let predicate = NSPredicate(format: "email == %@", defaultEmail)
        
        request.predicate = predicate
        do {
            var results = try managedContext.fetch(request)
            let objectUpdate = results[0] as! NSManagedObject
            objectUpdate.setValue(tf_name.text!, forKey: "name")
            objectUpdate.setValue(tf_email.text!, forKey: "email")
            objectUpdate.setValue(tf_phone.text!, forKey: "phoneNumber")
            var profileImageData:Data = Data()
            var bannerImageData:Data = Data()
            
            if let data1 = UIImageJPEGRepresentation(profileImage.image ?? UIImage(), 0.5) {
                profileImageData = data1
            }
            if let data2 = UIImageJPEGRepresentation(bannerImage.image ?? UIImage(), 0.5) {
                bannerImageData = data2
            }
            objectUpdate.setValue(profileImageData, forKey: "img")
            objectUpdate.setValue(bannerImageData, forKey: "bannerImg")
            
            userDefault.set(tf_email.text, forKey: "email")
            defaultEmail = userDefault.string(forKey: "email") ?? ""
            do {
                try managedContext.save()
                  SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.successMessages.profileUpdatedSuccessfully, viewController: self)
                
            }catch _ as NSError {
                print("error during updation profile information")
            }
        }
        catch _ as NSError {
            print("error during fetching profile information")
        }
    }
}

extension ProfileVC : UITextFieldDelegate{
    internal func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case tf_name:
            tf_email.becomeFirstResponder()
        case tf_email:
            tf_phone.becomeFirstResponder()
        case tf_phone:
            tf_phone.resignFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return true
    }
}
