//
//  ToDoDescriptionVC.swift
//  TodoList
//
//  Created by MacBook on 16/07/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import CoreData


enum status:String{
    case Done = "Done"
    case WorkInProgress = "Work in progress"
    case Pending = "Pending"
}

class ToDoDescriptionVC: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    var index = Int()
    var dict_todo = [String : String]()
    var todoList: [[String:String]] = []

    var taskTitleTextField = UITextField()
    var todoTitleTextField = UITextField()
    var todoDeadlineTextField = UITextField()
    var todoStatusTextField = UITextField()
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var groupType = String()
    let userDefault = UserDefaults.standard
    var defaultEmail = String()
    var arr_status: [String] = []
    let datePicker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        setUpTableView()
        defaultEmail = userDefault.string(forKey: "email") ?? ""
        todoList.removeAll()
        self.tableView.reloadData()
        self.todoList.append(dict_todo)
        self.tableView.reloadData()        
    }
    
    func setUpTableView(){
        tableView.register(UINib(nibName: "AddNewTaskInGroupCell", bundle: nil), forCellReuseIdentifier: "AddNewTaskInGroupCell")
    }
    
    @IBAction func actionOnBackButn(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
       
    @objc func actionOnEdit(sender:UIButton){
        let alert = UIAlertController(title: "Edit Group Task", message: "", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let action = UIAlertAction(title: "Edit Task", style: .default) { (action) in
            let context = self.appDelegate.persistentContainer.viewContext
            
            // Context can't be nil & also Make todoTaskTextField mandatory
            if self.todoTitleTextField.text != ""{
                let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: "Tasks")
                fetchRequest.predicate = NSPredicate(format: "groupType == %@",self.groupType)
                fetchRequest.returnsObjectsAsFaults = true
                
                do {
                    let results = try context.fetch(fetchRequest)
                  
                    let objectUpdate = results[sender.tag] as! NSManagedObject
                    
                    objectUpdate.setValue(self.todoTitleTextField.text, forKey: "taskName")
                    objectUpdate.setValue(self.groupType, forKey: "groupType")
                    objectUpdate.setValue(self.defaultEmail, forKey: "email")
                    objectUpdate.setValue(self.todoDeadlineTextField.text, forKey: "taskDeadline")
                    objectUpdate.setValue(self.todoStatusTextField.text, forKey: "status")
                    objectUpdate.setValue(self.taskTitleTextField.text, forKey: "title")
                    
                    let dict: [String:String] = ["email":self.defaultEmail,"taskName":self.todoTitleTextField.text!,"groupType":self.groupType,"taskDeadline": self.todoDeadlineTextField.text!,"status":self.todoStatusTextField.text!,"title":self.taskTitleTextField.text!]
                    
                    do {
                        try context.save()
                        self.todoList.remove(at: sender.tag)
                        self.tableView.reloadData()
                        self.todoList.insert(dict, at: sender.tag)
                        self.tableView.reloadData()
                    }catch _ as NSError {
                        print("error during updation todo list item")
                    }
                    
                }catch{
                    print("error")
                }
            }else{
                SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.taskAlertMessages.editToDoTask, viewController: self)
                return
            }
        }
        
        alert.addTextField { (textField) in
            textField.delegate = self
            textField.placeholder = "Edit Task Title"
            self.taskTitleTextField = textField
        }
        
        alert.addTextField { (textField) in
            textField.delegate = self
            textField.placeholder = "Edit Task Description"
            self.todoTitleTextField = textField
        }
        
        alert.addTextField { (textField) in
            self.addDatePicker(to: textField)
            textField.placeholder = "Edit Task Deadline"
            self.todoDeadlineTextField = textField
        }
        
        alert.addTextField { (textField) in
            self.addPicker(to: textField)
            textField.placeholder = "Edit Task Status"
            self.todoStatusTextField = textField
        }
        
        alert.addAction(action)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
        
        let todoItem = self.todoList[sender.tag]
        self.todoTitleTextField.text = todoItem["taskName"] ?? ""
        self.todoDeadlineTextField.text = todoItem["taskDeadline"] ?? ""
        self.todoStatusTextField.text = todoItem["status"] ?? ""
        self.taskTitleTextField.text = todoItem["title"] ?? ""
        
    }
    
    
    func addPicker(to textField: UITextField) {
        let PickerView:UIPickerView = UIPickerView()
        PickerView.delegate = self
        PickerView.dataSource = self
        textField.inputView = PickerView
    }
    
    func addDatePicker(to textField: UITextField) {
        self.datePicker.datePickerMode = .date
        if let dateText = textField.text, dateText != "" {
            datePicker.date = dateText.toDate(withFormattar: "yyyy-MM-dd") ?? Date()
        }
        datePicker.addTarget(self, action: #selector(AddNewTaskListingVC.datePickerDateDidChange(sender:)), for: UIControlEvents.valueChanged)
        textField.inputView = datePicker
        textField.text = formatDate(datePicker.date)
    }
    
    @objc func datePickerDateDidChange(sender: UIDatePicker) {
        self.todoDeadlineTextField.text = formatDate(datePicker.date)
    }
    
    func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
}

extension ToDoDescriptionVC:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return range.location < 50
    }
}

// MARK: - Extension for tableview methods
extension ToDoDescriptionVC: UITableViewDelegate, UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return todoList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddNewTaskInGroupCell", for: indexPath) as! AddNewTaskInGroupCell
        let dict = todoList[indexPath.row]
        let str_status = dict["status"] ?? ""
        if str_status == status.Pending.rawValue{
            cell.backgroundColor = UIColor(red: 255/255.0, green: 59/255.0, blue: 16/255.0, alpha: 1)
        }else if str_status == status.Done.rawValue{
            cell.backgroundColor = UIColor(red: 58.0/255.0, green: 255/255.0, blue: 60/255.0, alpha: 1)
        }else if str_status == status.WorkInProgress.rawValue{
            cell.backgroundColor = UIColor(red: 255/255.0, green: 252/255.0, blue: 121/255.0, alpha: 1)
        }
        cell.lbl_todoTitle.text = dict["taskName"] ?? ""
        cell.lbl_deadline.text = dict["taskDeadline"] ?? ""
        cell.lbl_taskTitle.text = dict["title"] ?? ""
        cell.btn_edit.tag = indexPath.row
        cell.btn_edit.addTarget(self, action: #selector(actionOnEdit), for: .touchUpInside)
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        let dict = todoList[indexPath.row]
        let descriptionScreen = self.storyboard?.instantiateViewController(withIdentifier: "ToDoDescriptionVC") as! ToDoDescriptionVC
        descriptionScreen.index = indexPath.row
        descriptionScreen.dict_todo = dict
        self.navigationController?.pushViewController(descriptionScreen, animated: true)
    }
}

extension ToDoDescriptionVC: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arr_status.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.todoStatusTextField.text = arr_status[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        if row == 0{
            self.todoStatusTextField.text = arr_status[row]
        }
        return arr_status[row]
    }
}
