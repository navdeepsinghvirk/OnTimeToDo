//
//  LeftMenuVC.swift
//  EdenCapital
//
//  Created by Macrew on 28/05/18.
//  Copyright © 2018 Macrew. All rights reserved.
//

import UIKit

class LeftMenuVC: UIViewController,SWRevealViewControllerDelegate {
	
    let userDefault = UserDefaults.standard

	override func viewDidLoad() {
		super.viewDidLoad()
	}
	
    @IBAction func logoutAction(_ sender: UIButton) {
        userDefault.removeObject(forKey: "email")
        let signInObj = self.storyboard?.instantiateViewController(withIdentifier: "SignInVC") as! SignInVC
        self.navigationController?.pushViewController(signInObj, animated: true)
    }
}
