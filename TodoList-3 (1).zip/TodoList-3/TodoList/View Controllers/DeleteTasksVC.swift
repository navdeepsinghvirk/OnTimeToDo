//
//  DeleteTasksVC.swift
//  TodoList
//
//  Created by MacBook on 22/05/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import CoreData


class DeleteTasksVC: UIViewController,SWRevealViewControllerDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var sideMenuButton: UIButton!
    @IBOutlet weak var popUpMessage: UILabel!
    
    
    var myArray : [[String:String]] = []
    let userDefault = UserDefaults.standard
    let appDelegate = UIApplication.shared.delegate as! AppDelegate
    var defaultEmail = String()
    let datePicker = UIDatePicker()
    var arr_status: [String] = []
    
    var taskTitleTextField = UITextField()
    var todoTitleTextField = UITextField()
    var todoDeadlineTextField = UITextField()
    var todoStatusTextField = UITextField()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        if revealViewController() != nil {
            revealViewController().delegate = self
            sideMenuButton.addTarget(revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)
            view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        }
        setUpTableView()
        arr_status = ["Pending","Work in progress","Done"]
        
        defaultEmail = userDefault.string(forKey: "email") ?? ""
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appDelegate.persistentContainer.viewContext
        
        let request = NSFetchRequest <NSFetchRequestResult> (entityName: "Tasks")
        request.predicate = NSPredicate(format: "email == %@", defaultEmail)
        request.returnsObjectsAsFaults = false
        do {
            let results = try context.fetch(request)
            // check data existance
            if results.count>0 {
                print(results.count)
                self.popUpMessage.isHidden = true
                
                for dict in results as! [NSManagedObject]{
                    
                    if let groupName = dict.value(forKey: "groupType") as? String{
                        let email = (dict.value(forKey: "email") as? String)!
                        let taskName = (dict.value(forKey: "taskName") as? String) ?? ""
                        let taskDeadline = (dict.value(forKey: "taskDeadline") as? String) ?? ""
                        let taskStatus = (dict.value(forKey: "status") as? String) ?? ""
                        let taskTitle = (dict.value(forKey: "title") as? String) ?? ""
                        
                        let dict: [String:String] = ["email":email,"groupType":groupName,"taskName":taskName,"taskDeadline":taskDeadline,"status":taskStatus,"title":taskTitle]
                        self.myArray.append(dict)
                        self.tableView.reloadData()
                    }
                }
            }
        }catch{
            print("No Data to load")
        }
        let longPressRecognizer = UILongPressGestureRecognizer(target: self, action: #selector(longPressed(sender:)))
        self.view.addGestureRecognizer(longPressRecognizer)
        
    }
    
    @objc func longPressed(sender: UILongPressGestureRecognizer) {
        
        if sender.state == UIGestureRecognizerState.began {
            
            let touchPoint = sender.location(in: self.tableView)
            if let indexPath = tableView.indexPathForRow(at: touchPoint) {
                
                print("Long pressed row: \(indexPath.row)")
                
                SwiftAlert().showWithCancelAndOk(title: GlobalConstants.appDetails.appName, okTitle: "Yes", cancelTitle: "Cancel", message: "Do you want to delete this task?", viewController: self, okAction: {
                    
                    let context = self.appDelegate.persistentContainer.viewContext
                    let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: "Tasks")
                    fetchRequest.returnsObjectsAsFaults = true
                    
                    do {
                        let results = try context.fetch(fetchRequest)
                        let objectUpdate = results[indexPath.row] as! NSManagedObject
                        do{
                            context.delete(objectUpdate)
                            self.myArray.remove(at: indexPath.row)
                            try context.save()
                            self.tableView.reloadData()
                            //let indexpath = IndexPath(row: myArray.count - 1, section: 0)
                            //tableView.deleteRows(at: [indexpath], with: .fade)
                        }catch{
                            fatalError("Error storing data")
                        }
                    }catch{
                        print("err")
                    }
                }, cancelAction: nil)
            }
        }
    }
    
    func setUpTableView() {
        tableView.register(UINib(nibName: "AddNewTaskInGroupCell", bundle: nil), forCellReuseIdentifier: "AddNewTaskInGroupCell")
    }
    
    
    func addDatePicker(to textField: UITextField) {
        self.datePicker.datePickerMode = .date
        if let dateText = textField.text, dateText != "" {
            datePicker.date = dateText.toDate(withFormattar: "yyyy-MM-dd") ?? Date()
        }
        datePicker.addTarget(self, action: #selector(DeleteTasksVC.datePickerDateDidChange(sender:)), for: UIControlEvents.valueChanged)
        textField.inputView = datePicker
        textField.text = formatDate(datePicker.date)
    }
    
    @objc func datePickerDateDidChange(sender: UIDatePicker) {
        self.todoDeadlineTextField.text = formatDate(datePicker.date)
    }
    
    func formatDate(_ date: Date) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.dateFormat = "dd-MM-yyyy"
        let formattedDate = dateFormatter.string(from: date)
        return formattedDate
    }
    
    func addPicker(to textField: UITextField) {
        let PickerView:UIPickerView = UIPickerView()
        PickerView.delegate = self
        PickerView.dataSource = self
        textField.inputView = PickerView
    }
    
    @objc func actionOnEdit(sender:UIButton){
        let dict = myArray[sender.tag]
        let groupType = dict["groupType"] ?? ""
        
        let alert = UIAlertController(title: "Edit Group Task", message: "", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        let action = UIAlertAction(title: "Edit Task", style: .default) { (action) in
            let context = self.appDelegate.persistentContainer.viewContext
            
            // Context can't be nil & also Make todoTaskTextField mandatory
            if self.todoTitleTextField.text != ""{
                let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: "Tasks")
                fetchRequest.returnsObjectsAsFaults = true
                
                do {
                    let results = try context.fetch(fetchRequest)
                    //                let entity = NSEntityDescription.entity(forEntityName: "Tasks", in: context)
                    //                let request = NSFetchRequest<NSFetchRequestResult>()
                    //                request.entity = entity
                    //                do {
                    //                    var results = try context.fetch(request)
                    let objectUpdate = results[sender.tag] as! NSManagedObject
                    
                    objectUpdate.setValue(self.todoTitleTextField.text, forKey: "taskName")
                    objectUpdate.setValue(groupType, forKey: "groupType")
                    objectUpdate.setValue(self.defaultEmail, forKey: "email")
                    objectUpdate.setValue(self.todoDeadlineTextField.text, forKey: "taskDeadline")
                    objectUpdate.setValue(self.todoStatusTextField.text, forKey: "status")
                    objectUpdate.setValue(self.taskTitleTextField.text, forKey: "title")
                    
                    let dict: [String:String] = ["email":self.defaultEmail,"taskName":self.todoTitleTextField.text!,"groupType":groupType ,"taskDeadline": self.todoDeadlineTextField.text!,"status":self.todoStatusTextField.text!,"title":self.taskTitleTextField.text!]
                    
                    do {
                        try context.save()
                        self.myArray.remove(at: sender.tag)
                        self.tableView.reloadData()
                        self.myArray.insert(dict, at: sender.tag)
                        self.tableView.reloadData()
                    }catch _ as NSError {
                        print("error during updation todo list item")
                    }
                    
                }catch{
                    print("error")
                }
            }else{
                SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.taskAlertMessages.editToDoTask, viewController: self)
                return
            }
        }
        
        alert.addTextField { (textField) in
            textField.delegate = self
            textField.placeholder = "Edit Task Title"
            self.taskTitleTextField = textField
        }
        
        alert.addTextField { (textField) in
            textField.delegate = self
            textField.placeholder = "Edit Task Description"
            self.todoTitleTextField = textField
        }
        
        alert.addTextField { (textField) in
            self.addDatePicker(to: textField)
            textField.placeholder = "Edit Task Deadline"
            self.todoDeadlineTextField = textField
        }
        
        alert.addTextField { (textField) in
            self.addPicker(to: textField)
            textField.placeholder = "Edit Task Status"
            self.todoStatusTextField = textField
        }
        
        alert.addAction(action)
        alert.addAction(cancelAction)
        present(alert, animated: true, completion: nil)
        
        let todoItem = self.myArray[sender.tag]
        self.todoTitleTextField.text = todoItem["taskName"] ?? ""
        self.todoDeadlineTextField.text = todoItem["taskDeadline"] ?? ""
        self.todoStatusTextField.text = todoItem["status"] ?? ""
        self.taskTitleTextField.text = todoItem["title"] ?? ""
    }
}


extension DeleteTasksVC:UITableViewDelegate,UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AddNewTaskInGroupCell", for: indexPath) as! AddNewTaskInGroupCell
        let dict = myArray[indexPath.row]
        
        let str_status = dict["status"] ?? ""
        if str_status == ToDoStatus.Pending.rawValue{
            cell.backgroundColor = UIColor(red: 255/255.0, green: 59/255.0, blue: 16/255.0, alpha: 1)
        }else if str_status == ToDoStatus.Done.rawValue{
            cell.backgroundColor = UIColor(red: 58.0/255.0, green: 255/255.0, blue: 60/255.0, alpha: 1)
        }else if str_status == ToDoStatus.WorkInProgress.rawValue{
            cell.backgroundColor = UIColor(red: 255/255.0, green: 252/255.0, blue: 121/255.0, alpha: 1)
        }
        cell.lbl_todoTitle.text = dict["taskName"] ?? ""
        cell.lbl_deadline.text = dict["taskDeadline"] ?? ""
        cell.lbl_taskTitle.text = dict["title"] ?? ""
        cell.btn_edit.tag = indexPath.row
        cell.btn_edit.addTarget(self, action: #selector(actionOnEdit), for: .touchUpInside)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120.0
    }
}

extension DeleteTasksVC:UITextFieldDelegate{
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return range.location < 50
    }
}

extension DeleteTasksVC: UIPickerViewDelegate,UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arr_status.count
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.todoStatusTextField.text = arr_status[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
        if row == 0{
            self.todoStatusTextField.text = arr_status[row]
        }
        return arr_status[row]
    }
}
