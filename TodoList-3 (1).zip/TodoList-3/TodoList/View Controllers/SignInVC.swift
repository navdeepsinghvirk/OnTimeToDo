//
//  SignInVC.swift
//  TodoList
//
//  Created by MacBook on 22/05/19.
//  Copyright © 2019 MacBook. All rights reserved.
//

import UIKit
import CoreData


class SignInVC: UIViewController {
    
    @IBOutlet weak var tf_password: UITextField!
    @IBOutlet weak var tf_email: UITextField!
    
    let userDefault = UserDefaults.standard
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
    }
    
    func setUp(){
        tf_email.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.emailText, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
        tf_password.attributedPlaceholder =
            NSAttributedString(string: GlobalConstants.textFieldMessage.passwordText, attributes: [NSAttributedStringKey.foregroundColor: UIColor.white])
    }
    
    func emailExists(id: String, entityName: String, type : String, fieldName : String) -> Bool {
        let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: entityName)
        if type == "String"{
            fetchRequest.predicate = NSPredicate(format: "\(fieldName) == %@", id)
        }else{
            fetchRequest.predicate = NSPredicate(format: "\(fieldName) == %d", id)
            
        }
        var results: [NSManagedObject] = []
        do {
            results = try (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext.fetch(fetchRequest) as! [NSManagedObject]
        }
        catch {
            print("error executing fetch request: \(error)")
        }
        
        return results.count > 0
    }
    
    func passwordExists(id: String, entityName: String, type : String, fieldName : String) -> Bool {
        let fetchRequest = NSFetchRequest <NSFetchRequestResult> (entityName: entityName)
        if type == "String"{
            fetchRequest.predicate = NSPredicate(format: "\(fieldName) == %@", id)
        }else{
            fetchRequest.predicate = NSPredicate(format: "\(fieldName) == %d", id)
            
        }
        
        var results: [NSManagedObject] = []
        do {
            results = try (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext.fetch(fetchRequest) as! [NSManagedObject]
        }
        catch {
            print("error executing fetch request: \(error)")
        }
        return results.count > 0
    }
    
    @IBAction func actionOnSignInBtn(_ sender: UIButton) {
        if emailExists(id:tf_email.text ?? "", entityName: "Users", type: "String", fieldName: "email") {
            if passwordExists(id:tf_password.text ?? "", entityName: "Users", type: "String", fieldName: "password") {
                //set email into userDefault, by using this mail we fetch all user information resp.
                userDefault.set(tf_email.text, forKey: "email")
                let leftMenu = self.storyboard?.instantiateViewController(withIdentifier: "swReveal") as! SWRevealViewController
                self.navigationController?.pushViewController(leftMenu, animated: true)
            }else{
                SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.successMessages.incorrectPassword, viewController: self)
            }
        }else{
            SwiftAlert().show(title: GlobalConstants.appDetails.appName, message: GlobalConstants.successMessages.emailInvalid, viewController: self)
        }
    }
}
extension SignInVC : UITextFieldDelegate{
    internal func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case tf_email:
            tf_password.becomeFirstResponder()
        case tf_password:
            tf_password.resignFirstResponder()
        default:
            textField.resignFirstResponder()
        }
        return true
    }
}
