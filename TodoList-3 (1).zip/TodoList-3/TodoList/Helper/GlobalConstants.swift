//
//  GlobalConstants.swift
//  Hotwear
//
//  Created by Mac OSX on 22/01/18.
//  Copyright © 2018 Macrew. All rights reserved.
//

import Foundation
import UIKit


struct GlobalConstants {
    struct appDetails {
        static let appName = "Todo List"
        static let website = ""
        static let version = (Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String) ?? ""
        let applicationDelegate = UIApplication.shared.delegate as! AppDelegate
    }
    
    struct TaskType {
     static let shopping = "Shopping List"
     static let assignments = "Assignment"
     static let attendance = "Attendance"
    }
    
    struct successMessages {
        static let registeredSuccessfully = "User registered successfully!"
        static let incorrectPassword = "Incorrect Password!"
        static let emailInvalid = "Email doesn't exist!"
        static let profileUpdatedSuccessfully = "Your profile updated successfully!"
    }
    
    struct textFieldMessage {
        static let usernameText = "Username"
        static let passwordText = "Password"
		static let emailText = "E-mail"
		static let name = "Name"
		static let lastName = "Last Name"
		static let phoneNumber = "Phone Number"
		static let emailAddress = "Email"
		static let yourAddress = "Your Address"
		
    }
    
    struct taskAlertMessages{
        static let enterToDoTask  = "Empty todo task can't be added!"
        static let editToDoTask  = "Empty todo task can't be edited!"

        static let NotHavingAnyTaskYet = "You have no task yet! please click to add(+) button to insert new task."
    }
    
    struct  alertMessages {
        static let mandatoryFields = "All fields are mandatory"
        static let emailFields = "Please enter your email"
        static let phoneNumberFields = "Please enter your phone number"
        static let nameFields = "Please enter your name"
        static let passwordFields = "Please enter your password"
        static let invalidCredentials = "This email and password doesn't exist."

    }
}
