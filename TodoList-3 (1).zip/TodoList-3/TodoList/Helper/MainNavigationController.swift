//
//  MainNavigationController.swift
//  Nago
//
//  Created by OSX on 09/03/18.
//  Copyright © 2018 Macrew Technologies. All rights reserved.
//

import UIKit

class MainNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
         // self.navigationBar.barTintColor = UIColor.white //UIColor(red: 18/255, green: 33/255, blue: 179/255, alpha: 1)
		
        let imageView = UIImageView(image: UIImage.init(named: "logo"))
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 200, height: 44))
        view.addSubview(imageView)
        navigationItem.titleView = view
        let textAttributes = [NSAttributedStringKey.foregroundColor: UIColor.red]
	    self.navigationBar.titleTextAttributes = textAttributes
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
}
